﻿using G9SuperNetCoreClient.Abstract;

namespace G9SuperNetCoreClient.Sample
{
    public class ClientSessionSample : AClientSession
    {
    }
}