﻿namespace G9SuperNetCoreClient.Enums
{
    public enum ClientStopReason : byte
    {
        NONE
    }
}