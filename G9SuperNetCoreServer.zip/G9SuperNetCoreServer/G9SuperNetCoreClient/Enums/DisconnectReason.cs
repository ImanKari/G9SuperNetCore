﻿namespace G9SuperNetCoreClient.Enums
{
    public enum DisconnectReason : byte
    {
        /// <summary>
        ///     Unknown reason
        /// </summary>
        Unknown,

        /// <summary>
        ///     When disconnected from server
        /// </summary>
        DisconnectedFromServer,

        /// <summary>
        ///     When client disconnected with program (used method disconnect)
        /// </summary>
        DisconnectedByProgram,

        /// <summary>
        ///     When client receive certificate but private key is not correct and can't read certificate
        /// </summary>
        AuthorizationFailPrivateKeyNotCorrect,

        /// <summary>
        ///     When client receive certificate but certificate is damage and can't read it
        /// </summary>
        AuthorizationFailCertificateIsDamage,

        /// <summary>
        ///     When client receive certificate but can't use certificate | Reason: unknown
        /// </summary>
        AuthorizationFailUnknownError

    }
}