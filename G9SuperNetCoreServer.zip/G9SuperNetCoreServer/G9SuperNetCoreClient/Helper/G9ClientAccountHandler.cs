﻿namespace G9SuperNetCoreClient.Helper
{
    public struct G9ClientAccountHandler
    {

    }
}