﻿using G9Common.Abstract;

namespace G9SuperNetCoreClient.Helper
{
    public class G9ClientSessionHandler : ASessionHandler
    {
    }
}