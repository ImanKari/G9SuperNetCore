﻿using System;
using G9SuperNetCoreServer.Abstarct;

namespace G9SuperNetCoreServer.Sample
{
    public class ServerSessionSample : AServerSession
    {
        
    }

    
}