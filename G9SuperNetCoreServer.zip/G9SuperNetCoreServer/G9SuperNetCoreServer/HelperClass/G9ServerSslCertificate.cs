﻿using System;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using G9Common.HelperClass;
using G9Common.RandomNumberWithoutDuplicates;
using G9Common.Resource;

namespace G9SuperNetCoreServer.HelperClass
{
    /// <summary>
    ///     Management certificates for server ssl connection
    /// </summary>
    public class G9ServerSslCertificate : G9SslCertificate
    {
        #region Fields And Properties

        /// <summary>
        ///     Specified certificates for ssl connection
        /// </summary>
        public readonly X509Certificate2[] Certificates;

        #endregion

        #region Methods

        /// <summary>
        ///     <para>Constructor</para>
        ///     <para>Initialize requirement</para>
        /// </summary>
        /// <param name="privateKey">
        ///     <para>
        ///         Notice: This is not a certificate password, it is a private, shared key between the client and the server for
        ///         secure communication
        ///     </para>
        ///     <para>Specified custom private key (not is cer</para>
        ///     <para>Maximum length is 255</para>
        /// </param>
        /// <param name="exportableCertificates">Exportable certificates</param>

        #region G9ServerSslCertificate

        public G9ServerSslCertificate(string privateKey, params X509Certificate2[] exportableCertificates) :
            base(privateKey)
        {
            // Check certificates is exportable
            if (exportableCertificates.Any(s => !G9EncryptAndDecryptDataWithCertificate.CheckCertificateIsExportable(s, X509ContentType.Pkcs12)))
                throw new Exception(LogMessage.CertificateIsNotExportable);
            // Set certificates
            Certificates = exportableCertificates;
        }

        #endregion

        /// <summary>
        ///     <para>Constructor</para>
        ///     <para>Initialize requirement</para>
        ///     <para>Use random generated certificate</para>
        /// </summary>
        /// <param name="privateKey">
        ///     <para>
        ///         Notice: This is not a certificate password, it is a private, shared key between the client and the server for
        ///         secure communication
        ///     </para>
        ///     <para>Specified custom private key (not is cer</para>
        ///     <para>Maximum length is 255</para>
        /// </param>
        /// <param name="countOfRandomCertificateGenerate">
        /// <para>Specified count of the certificate to be generated randomly</para>
        /// <para>Notice: Certificate generated programmatically with random data</para>
        /// </param>
        #region G9ServerSslCertificate
        public G9ServerSslCertificate(string privateKey, ushort countOfRandomCertificateGenerate, string countryCode = "US") :
            base(privateKey)
        {
            // Check country code
            if (countryCode.Length != 2)
                throw new ArgumentException(LogMessage.CountryCodeIsTwoChar, nameof(countryCode));

            // Instance object for get random number
            G9RandomNumberWithoutDuplicates randomNumberWithoutDuplicates = new G9RandomNumberWithoutDuplicates();

            // Initialize certificates array
            Certificates = new X509Certificate2[countOfRandomCertificateGenerate];

            // Initialize random pfx certificates
            for (ushort i = 0; i < countOfRandomCertificateGenerate; i++)
            {
                Certificates[i] = GenerateCustomX509Certificate2(
                    $"{STARTER_PRIVATE_KEY}{randomNumberWithoutDuplicates.Next(111111111, 999999999)}",
                    $"{DEFAULT_PRIVATE_KEY}{randomNumberWithoutDuplicates.Next(111111111, 999999999)}",
                    $"XIXO-{randomNumberWithoutDuplicates.Next(111111111, 999999999)}",
                    countryCode: countryCode);
            }

        }
        #endregion

        /// <summary>
        ///     Generate custom X509Certificate2 like pfx
        /// </summary>

        #region GenerateCustomX509Certificate2

        public static X509Certificate2 GenerateCustomX509Certificate2(string commonName, string password,
            string friendlyName = null, string[] dnsNames = null, DateTime? expirationBefore = null,
            DateTime? expirationAfter = null, bool isCertificateAuthority = false, string countryCode = "US",
            string organization = "JCCE", string[] organizationalUnits = null)
        {
            var sanBuilder = new SubjectAlternativeNameBuilder();
            if (dnsNames == null)
            {
                sanBuilder.AddIpAddress(IPAddress.Loopback);
                sanBuilder.AddIpAddress(IPAddress.IPv6Loopback);
                sanBuilder.AddDnsName("localhost");
                sanBuilder.AddDnsName(Environment.MachineName);
            }
            else
            {
                foreach (var dnsName in dnsNames) sanBuilder.AddDnsName(dnsName);
            }

            if (countryCode.Length != 2) countryCode = "US";

            if (organizationalUnits == null)
                organizationalUnits = new[] {"Copyright (c), " + DateTime.UtcNow.ToString("yyyy") + " JCCE"};

            var dn = new StringBuilder();

            dn.Append("CN=\"" + commonName.Replace("\"", "\"\"") + "\"");
            foreach (var ou in organizationalUnits) dn.Append(",OU=\"" + ou.Replace("\"", "\"\"") + "\"");
            dn.Append(",O=\"" + organization.Replace("\"", "\"\"") + "\"");
            dn.Append(",C=" + countryCode.ToUpper());
            dn.Append(",C=" + "JP");

            var strDn = dn.ToString();

            var distinguishedName = new X500DistinguishedName(strDn);

            X509Certificate2 cert;

            using (var rsa = RSA.Create(2048))
            {
                var request = new CertificateRequest(distinguishedName, rsa, HashAlgorithmName.SHA256,
                    RSASignaturePadding.Pkcs1);

                var usages = X509KeyUsageFlags.DataEncipherment | X509KeyUsageFlags.KeyEncipherment |
                             X509KeyUsageFlags.DigitalSignature;

                if (isCertificateAuthority) usages = usages | X509KeyUsageFlags.KeyCertSign;

                request.CertificateExtensions.Add(new X509KeyUsageExtension(usages, false));


                request.CertificateExtensions.Add(
                    new X509EnhancedKeyUsageExtension(
                        new OidCollection {new Oid("1.3.6.1.5.5.7.3.1")}, false));

                request.CertificateExtensions.Add(sanBuilder.Build());

                if (isCertificateAuthority)
                    request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, true, 1, true));

                if (expirationAfter == null) expirationAfter = DateTime.UtcNow.AddDays(-1).AddYears(10);

                if (expirationBefore == null) expirationBefore = DateTime.UtcNow;

                var certificate = request.CreateSelfSigned(new DateTimeOffset(expirationBefore.Value),
                    new DateTimeOffset(expirationAfter.Value));
                if (friendlyName == null) friendlyName = commonName;
                certificate.FriendlyName = friendlyName;

                cert = new X509Certificate2(certificate.Export(X509ContentType.Pfx, password), password,
                    X509KeyStorageFlags.Exportable);

                // If need certificate pfx file
                // File.WriteAllBytes(path, certificate.Export(X509ContentType.Pkcs12, Password));
            }

            return cert;
        }

        #endregion

        #endregion
    }
}