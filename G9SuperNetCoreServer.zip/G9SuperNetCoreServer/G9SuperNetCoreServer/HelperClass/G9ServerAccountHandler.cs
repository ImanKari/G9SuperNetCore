﻿namespace G9SuperNetCoreServer.HelperClass
{
    public struct G9ServerAccountHandler
    {

    }
}