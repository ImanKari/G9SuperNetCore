﻿namespace G9Common.Enums
{
    /// <summary>
    ///     Send type for command
    /// </summary>
    public enum SendTypeForCommand
    {
        Asynchronous,
        Synchronous
    }
}