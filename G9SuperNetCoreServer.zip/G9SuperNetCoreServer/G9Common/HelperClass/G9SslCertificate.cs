﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace G9Common.HelperClass
{
    public class G9SslCertificate
    {
        /// <summary>
        /// Specified private key
        /// Maximum length is 255 
        /// </summary>
        public readonly string PrivateKey;

        /// <summary>
        /// Specified starter private key
        /// </summary>
        protected const string STARTER_PRIVATE_KEY = "G9TM-";

        /// <summary>
        /// Specified default private key
        /// </summary>
        protected const string DEFAULT_PRIVATE_KEY = "@ThisIsG9Team";

        #region Methods

        /// <summary>
        /// <para>Constructor</para>
        /// <para>Initialize Requirement</para>
        /// </summary>
        /// <param name="privateKey">
        ///     <para>Notice: This is not a certificate password, it is a private, shared key between the client and the server for secure communication</para>
        ///     <para>Specified custom private key (not is cer</para>
        ///     <para>Maximum length is 255</para>
        /// </param>
        #region G9SslCertificate
        public G9SslCertificate(string privateKey)
        {
            // Check private key and set default private key if it's null or empty
            if (string.IsNullOrEmpty(privateKey))
                privateKey = DEFAULT_PRIVATE_KEY;

            // Generate new private key by private key
            PrivateKey = GenerateNewPrivateKey(privateKey);
        }
        #endregion

        /// <summary>
        /// Generate new private key by private key
        /// </summary>
        /// <param name="privateKey">specified private key</param>
        /// <returns>Generated new private key</returns>
        #region GenerateNewPrivateKey
        private string GenerateNewPrivateKey(string privateKey)
        {
            if (privateKey.Length > 218)
            {
                privateKey = privateKey.Substring(0, 186) + CreateMD5(privateKey.Substring(186));
            }
            else if (privateKey.Length < 218)
            {
                while (privateKey.Length < 218)
                {
                    if ((privateKey.Length & 1) == 1)
                        privateKey += CreateMD5(privateKey);
                    else
                        privateKey = CreateMD5(privateKey) + privateKey;
                }
                privateKey = privateKey.Substring(0, 186) + CreateMD5(privateKey.Substring(186));
            }
            else
                privateKey += CreateMD5(privateKey);

            return STARTER_PRIVATE_KEY + privateKey;
        }
        #endregion

        public static string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using MD5 md5 = MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hashBytes = md5.ComputeHash(inputBytes);

            // Convert the byte array to hexadecimal string
            StringBuilder sb = new StringBuilder();
            for (var i = 0; i < hashBytes.Length; i++) sb.Append(hashBytes[i].ToString("X2"));
            return sb.ToString();
        }
        #endregion
    }
}
